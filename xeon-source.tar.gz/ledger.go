package main

import (
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
)

const (
	LedgerChainID = "xeon-v2-local"
)

type Account struct {
	Balance int64  `json:"balance"`
	Nonce   uint64 `json:"nonce"`
}

type LedgerState struct {
	Version           int                `json:"version"`
	ChainID           string             `json:"chain_id"`
	Accounts          map[string]Account `json:"accounts"`
	GenesisAddress    string             `json:"genesis_address"`
	GenesisAllocation int64              `json:"genesis_allocation"`
	EmergencyReserve  int64              `json:"emergency_reserve"`
	RewardReserve     int64              `json:"reward_reserve"`
}

type Ledger struct {
	mu       sync.Mutex
	state    LedgerState
	dataPath string
}

// Validasi alamat 20-byte yang ditulis sebagai 40 karakter hex.
func normalizeAddress(address string) (string, error) {
	address = strings.ToLower(strings.TrimSpace(address))

	if len(address) != 40 {
		return "", errors.New("alamat harus terdiri dari 40 karakter hex")
	}

	raw, err := hex.DecodeString(address)
	if err != nil || len(raw) != 20 {
		return "", errors.New("alamat tidak valid")
	}

	return address, nil
}

func NewLedger(path, genesisAddress string) (*Ledger, error) {
	address, err := normalizeAddress(genesisAddress)
	if err != nil {
		return nil, fmt.Errorf("alamat Genesis: %w", err)
	}

	ledger := &Ledger{
		dataPath: path,
		state: LedgerState{
			Version:           1,
			ChainID:           LedgerChainID,
			Accounts:          make(map[string]Account),
			GenesisAddress:    address,
			GenesisAllocation: GenesisAllocation,
			EmergencyReserve:  EmergencyReserve,
			RewardReserve:     RewardReserve,
		},
	}

	raw, err := os.ReadFile(path)
	if err == nil {
		if err := json.Unmarshal(raw, &ledger.state); err != nil {
			return nil, fmt.Errorf("file ledger rusak: %w", err)
		}

		if ledger.state.Version != 1 {
			return nil, errors.New("versi ledger tidak didukung")
		}

		if ledger.state.ChainID != LedgerChainID {
			return nil, errors.New("chain ID ledger tidak sesuai")
		}

		if ledger.state.GenesisAddress != address {
			return nil, errors.New("alamat Genesis berbeda dari ledger yang tersimpan")
		}

		if err := ledger.validateState(ledger.state); err != nil {
			return nil, fmt.Errorf("ledger tidak valid: %w", err)
		}

		return ledger, nil
	}

	if !os.IsNotExist(err) {
		return nil, err
	}

	if GenesisAllocation+EmergencyReserve+RewardReserve != MaxSupply {
		return nil, errors.New("alokasi suplai tidak valid")
	}

	ledger.state.Accounts[address] = Account{
		Balance: GenesisAllocation,
		Nonce:   0,
	}

	if err := ledger.saveLocked(); err != nil {
		return nil, err
	}

	return ledger, nil
}

func (l *Ledger) validateState(state LedgerState) error {
	if state.Accounts == nil {
		return errors.New("accounts tidak boleh kosong")
	}

	if state.GenesisAllocation != GenesisAllocation ||
		state.EmergencyReserve != EmergencyReserve ||
		state.RewardReserve != RewardReserve {
		return errors.New("alokasi suplai berbeda dari konfigurasi protokol")
	}

	if state.GenesisAllocation < 0 ||
		state.EmergencyReserve < 0 ||
		state.RewardReserve < 0 {
		return errors.New("alokasi negatif tidak diizinkan")
	}

	if state.GenesisAllocation+state.EmergencyReserve+state.RewardReserve > MaxSupply {
		return errors.New("alokasi melebihi suplai maksimum")
	}

	var totalBalances int64

	for address, account := range state.Accounts {
		if _, err := normalizeAddress(address); err != nil {
			return err
		}

		if account.Balance < 0 {
			return errors.New("saldo negatif terdeteksi")
		}

		if account.Balance > MaxSupply-totalBalances {
			return errors.New("total saldo melebihi suplai maksimum")
		}

		totalBalances += account.Balance
	}

	if totalBalances > state.GenesisAllocation {
		return errors.New("saldo pengguna melebihi alokasi Genesis")
	}

	return nil
}

func (l *Ledger) saveLocked() error {
	if l.dataPath == "" {
		return errors.New("jalur penyimpanan ledger kosong")
	}

	if err := os.MkdirAll(filepath.Dir(l.dataPath), 0700); err != nil {
		return err
	}

	raw, err := json.MarshalIndent(l.state, "", "  ")
	if err != nil {
		return err
	}

	tmp := l.dataPath + ".tmp"

	file, err := os.OpenFile(
		tmp,
		os.O_CREATE|os.O_TRUNC|os.O_WRONLY,
		0600,
	)
	if err != nil {
		return err
	}

	if _, err := file.Write(raw); err != nil {
		file.Close()
		return err
	}

	if err := file.Sync(); err != nil {
		file.Close()
		return err
	}

	if err := file.Close(); err != nil {
		return err
	}

	if err := os.Rename(tmp, l.dataPath); err != nil {
		return err
	}

	return nil
}

func (l *Ledger) Balance(address string) (int64, error) {
	address, err := normalizeAddress(address)
	if err != nil {
		return 0, err
	}

	l.mu.Lock()
	defer l.mu.Unlock()

	return l.state.Accounts[address].Balance, nil
}

func (l *Ledger) AccountInfo(address string) (Account, error) {
	address, err := normalizeAddress(address)
	if err != nil {
		return Account{}, err
	}

	l.mu.Lock()
	defer l.mu.Unlock()

	return l.state.Accounts[address], nil
}

// ApplyTransaction hanya memperbarui ledger setelah signature,
// chain ID, nonce, dan saldo dinyatakan valid.
func (l *Ledger) ApplyTransaction(tx Transaction) error {
	if err := tx.Verify(LedgerChainID); err != nil {
		return fmt.Errorf("transaksi tidak valid: %w", err)
	}

	from, err := normalizeAddress(tx.From)
	if err != nil {
		return err
	}

	to, err := normalizeAddress(tx.To)
	if err != nil {
		return err
	}

	l.mu.Lock()
	defer l.mu.Unlock()

	sender := l.state.Accounts[from]
	receiver := l.state.Accounts[to]

	if sender.Nonce == ^uint64(0) {
		return errors.New("nonce pengirim mencapai batas")
	}

	expectedNonce := sender.Nonce + 1
	if tx.Nonce != expectedNonce {
		return fmt.Errorf(
			"nonce tidak sesuai: mengharapkan %d, menerima %d",
			expectedNonce,
			tx.Nonce,
		)
	}

	if sender.Balance < tx.Amount {
		return errors.New("saldo tidak mencukupi")
	}

	if receiver.Balance > MaxSupply-tx.Amount {
		return errors.New("saldo penerima akan melebihi batas protokol")
	}

	// Buat kandidat state agar perubahan tidak diterapkan sebagian.
	candidate := l.state
	candidate.Accounts = make(map[string]Account, len(l.state.Accounts))

	for address, account := range l.state.Accounts {
		candidate.Accounts[address] = account
	}

	sender.Balance -= tx.Amount
	sender.Nonce++

	receiver.Balance += tx.Amount

	candidate.Accounts[from] = sender
	candidate.Accounts[to] = receiver

	if err := l.validateState(candidate); err != nil {
		return fmt.Errorf("state transaksi tidak valid: %w", err)
	}

	previous := l.state
	l.state = candidate

	if err := l.saveLocked(); err != nil {
		l.state = previous
		return fmt.Errorf("gagal menyimpan transaksi: %w", err)
	}

	return nil
}

func (l *Ledger) Snapshot() LedgerState {
	l.mu.Lock()
	defer l.mu.Unlock()

	raw, _ := json.Marshal(l.state)

	var copyState LedgerState
	_ = json.Unmarshal(raw, &copyState)

	return copyState
}
