package main

import (
	"crypto/ed25519"
	"crypto/rand"
	"encoding/hex"
	"strings"
	"testing"
)

func makeTestValidators(t *testing.T, n int) ([]Validator, []ed25519.PrivateKey) {
	t.Helper()
	vs := make([]Validator, n)
	keys := make([]ed25519.PrivateKey, n)
	for i := 0; i < n; i++ {
		pub, priv, err := ed25519.GenerateKey(rand.Reader)
		if err != nil {
			t.Fatal(err)
		}
		vs[i] = Validator{
			Address:   AddressFromPublicKey(pub),
			PublicKey: hex.EncodeToString(pub),
			Stake:     1,
			Active:    true,
		}
		keys[i] = priv
	}
	return vs, keys
}

func TestQuorum(t *testing.T) {
	cases := []struct{ n, want int }{
		{1, 1}, {2, 2}, {3, 3}, {4, 3}, {5, 4}, {6, 5}, {7, 5},
	}
	for _, c := range cases {
		got, err := BFTQuorum(c.n)
		if err != nil || got != c.want {
			t.Fatalf("n=%d got=%d want=%d err=%v", c.n, got, c.want, err)
		}
	}
	if _, err := BFTQuorum(0); err == nil {
		t.Fatal("quorum menerima nol validator")
	}
}

func TestValidatorSet(t *testing.T) {
	vs, _ := makeTestValidators(t, 4)
	if err := ValidateValidatorSet(vs); err != nil {
		t.Fatalf("validator sah ditolak: %v", err)
	}

	dup := append([]Validator(nil), vs...)
	dup[1].Address = dup[0].Address
	if err := ValidateValidatorSet(dup); err == nil {
		t.Fatal("alamat validator duplikat diterima")
	}

	inactive := append([]Validator(nil), vs...)
	for i := range inactive {
		inactive[i].Active = false
	}
	if err := ValidateValidatorSet(inactive); err == nil {
		t.Fatal("validator tanpa anggota aktif diterima")
	}
}

func TestVoteSignatureAndChainID(t *testing.T) {
	vs, keys := makeTestValidators(t, 4)
	v := ConsensusVote{
		ChainID:   "xeon-test",
		Height:    1,
		Round:     0,
		BlockHash: strings.Repeat("a", 64),
		Type:      VotePrevote,
	}

	if err := v.Sign(keys[0]); err != nil {
		t.Fatal(err)
	}
	if err := v.Verify("xeon-test", vs); err != nil {
		t.Fatalf("vote sah ditolak: %v", err)
	}
	if err := v.Verify("chain-salah", vs); err == nil {
		t.Fatal("vote dengan chain ID salah diterima")
	}

	bad := v
	bad.Signature = strings.Repeat("0", 128)
	if err := bad.Verify("xeon-test", vs); err == nil {
		t.Fatal("tanda tangan palsu diterima")
	}

	bad = v
	bad.BlockHash = strings.Repeat("b", 64)
	if err := bad.Verify("xeon-test", vs); err == nil {
		t.Fatal("hash yang diubah tanpa tanda tangan baru diterima")
	}
}

func TestBFTDuplicateVoteAndFinalization(t *testing.T) {
	validators, keys := makeTestValidators(t, 4)
	e, err := NewConsensusEngine("xeon-test", 0, validators)
	if err != nil {
		t.Fatal(err)
	}

	hash := strings.Repeat("a", 64)
	other := strings.Repeat("b", 64)

	makeVote := func(i int, typ VoteType, blockHash string) ConsensusVote {
		t.Helper()
		v := ConsensusVote{
			ChainID:   "xeon-test",
			Height:    1,
			Round:     0,
			BlockHash: blockHash,
			Type:      typ,
		}
		if err := v.Sign(keys[i]); err != nil {
			t.Fatal(err)
		}
		return v
	}

	// Vote kedua dari validator yang sama harus ditolak.
	v := makeVote(0, VotePrevote, hash)
	if err := e.SubmitVote(v); err != nil {
		t.Fatal(err)
	}
	if err := e.SubmitVote(v); err == nil {
		t.Fatal("vote duplikat diterima")
	}

	// Dua dari empat validator belum mencapai quorum.
	if err := e.SubmitVote(makeVote(1, VotePrevote, hash)); err != nil {
		t.Fatal(err)
	}
	if err := e.BeginPrecommit(hash); err == nil {
		t.Fatal("precommit dimulai tanpa quorum prevote")
	}

	// Validator ketiga membuat quorum prevote.
	if err := e.SubmitVote(makeVote(2, VotePrevote, hash)); err != nil {
		t.Fatal(err)
	}
	if err := e.BeginPrecommit(hash); err != nil {
		t.Fatalf("gagal memulai precommit: %v", err)
	}

	// Precommit untuk hash berbeda harus ditolak.
	if err := e.SubmitVote(makeVote(3, VotePrecommit, other)); err == nil {
		t.Fatal("precommit dengan hash berbeda diterima")
	}

	// Dua precommit belum cukup; finalisasi harus gagal.
	if err := e.SubmitVote(makeVote(0, VotePrecommit, hash)); err != nil {
		t.Fatal(err)
	}
	if err := e.SubmitVote(makeVote(1, VotePrecommit, hash)); err != nil {
		t.Fatal(err)
	}
	if err := e.Finalize(hash); err == nil {
		t.Fatal("blok difinalisasi tanpa quorum precommit")
	}

	// Precommit ketiga mencapai quorum.
	if err := e.SubmitVote(makeVote(2, VotePrecommit, hash)); err != nil {
		t.Fatal(err)
	}

	if err := e.Finalize(other); err == nil {
		t.Fatal("hash yang tidak terkunci berhasil difinalisasi")
	}
	if err := e.Finalize(hash); err != nil {
		t.Fatalf("finalisasi setelah quorum gagal: %v", err)
	}
	if err := e.NextHeight(); err != nil {
		t.Fatalf("gagal berpindah ke tinggi berikutnya: %v", err)
	}
}

func TestBFTRejectsRoundChangeWhileLocked(t *testing.T) {
	validators, keys := makeTestValidators(t, 4)
	e, err := NewConsensusEngine("xeon-test", 0, validators)
	if err != nil {
		t.Fatal(err)
	}

	hash := strings.Repeat("c", 64)
	for i := 0; i < 3; i++ {
		v := ConsensusVote{
			ChainID:   "xeon-test",
			Height:    1,
			Round:     0,
			BlockHash: hash,
			Type:      VotePrevote,
		}
		if err := v.Sign(keys[i]); err != nil {
			t.Fatal(err)
		}
		if err := e.SubmitVote(v); err != nil {
			t.Fatal(err)
		}
	}

	if err := e.BeginPrecommit(hash); err != nil {
		t.Fatalf("gagal mengunci hash setelah quorum: %v", err)
	}
	if err := e.NextRound(); err == nil {
		t.Fatal("pergantian round diterima saat lock masih aktif")
	}
}
