package main

import (
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
)

type Validator struct {
	Address   string `json:"address"`
	PublicKey string `json:"public_key"`
	Stake     int64  `json:"stake"`
	Active    bool   `json:"active"`
}

type VoteType string

const (
	VotePrevote   VoteType = "PREVOTE"
	VotePrecommit VoteType = "PRECOMMIT"
)

type ConsensusVote struct {
	ChainID   string   `json:"chain_id"`
	Height    uint64   `json:"height"`
	Round     uint64   `json:"round"`
	BlockHash string   `json:"block_hash"`
	Type      VoteType `json:"type"`
	Validator string   `json:"validator"`
	Signature string   `json:"signature"`
}

type votePayload struct {
	ChainID   string   `json:"chain_id"`
	Height    uint64   `json:"height"`
	Round     uint64   `json:"round"`
	BlockHash string   `json:"block_hash"`
	Type      VoteType `json:"type"`
	Validator string   `json:"validator"`
}

func (v ConsensusVote) SigningBytes() ([]byte, error) {
	return json.Marshal(votePayload{ChainID: v.ChainID, Height: v.Height, Round: v.Round, BlockHash: strings.ToLower(strings.TrimSpace(v.BlockHash)), Type: v.Type, Validator: strings.ToLower(strings.TrimSpace(v.Validator))})
}

func (v *ConsensusVote) Sign(privateKey ed25519.PrivateKey) error {
	if v == nil {
		return errors.New("vote nil")
	}
	if len(privateKey) != ed25519.PrivateKeySize {
		return errors.New("private key validator tidak valid")
	}
	publicKey := privateKey.Public().(ed25519.PublicKey)
	v.Validator = AddressFromPublicKey(publicKey)
	message, err := v.SigningBytes()
	if err != nil {
		return err
	}
	v.Signature = hex.EncodeToString(ed25519.Sign(privateKey, message))
	return nil
}

func (v ConsensusVote) Verify(chainID string, validators []Validator) error {
	if v.ChainID != chainID || strings.TrimSpace(chainID) == "" {
		return errors.New("chain ID vote tidak sesuai")
	}
	if v.Height == 0 {
		return errors.New("height vote tidak valid")
	}
	if v.Type != VotePrevote && v.Type != VotePrecommit {
		return errors.New("jenis vote tidak dikenal")
	}
	if len(v.BlockHash) != 64 {
		return errors.New("hash blok harus 32-byte hex")
	}
	if _, err := hex.DecodeString(v.BlockHash); err != nil {
		return errors.New("hash blok bukan hex valid")
	}
	var matched *Validator
	for i := range validators {
		if strings.EqualFold(strings.TrimSpace(validators[i].Address), strings.TrimSpace(v.Validator)) {
			matched = &validators[i]
			break
		}
	}
	if matched == nil || !matched.Active {
		return errors.New("validator tidak terdaftar atau tidak aktif")
	}
	pubBytes, err := hex.DecodeString(matched.PublicKey)
	if err != nil || len(pubBytes) != ed25519.PublicKeySize {
		return errors.New("public key validator tidak valid")
	}
	pub := ed25519.PublicKey(pubBytes)
	if !strings.EqualFold(AddressFromPublicKey(pub), matched.Address) {
		return errors.New("alamat validator tidak cocok dengan public key")
	}
	sig, err := hex.DecodeString(v.Signature)
	if err != nil || len(sig) != ed25519.SignatureSize {
		return errors.New("signature vote tidak valid")
	}
	message, err := v.SigningBytes()
	if err != nil {
		return err
	}
	if !ed25519.Verify(pub, message, sig) {
		return errors.New("signature vote gagal diverifikasi")
	}
	return nil
}

func BFTQuorum(totalValidators int) (int, error) {
	if totalValidators <= 0 {
		return 0, errors.New("validator aktif tidak tersedia")
	}
	return (2*totalValidators)/3 + 1, nil
}

func ValidateValidatorSet(validators []Validator) error {
	if len(validators) == 0 {
		return errors.New("validator set kosong")
	}
	addresses, publicKeys := make(map[string]bool), make(map[string]bool)
	activeCount := 0
	for _, v := range validators {
		address := strings.ToLower(strings.TrimSpace(v.Address))
		if len(address) != AddressLength {
			return fmt.Errorf("alamat validator tidak valid: %s", v.Address)
		}
		if _, err := hex.DecodeString(address); err != nil {
			return errors.New("alamat validator bukan hex valid")
		}
		if addresses[address] {
			return errors.New("alamat validator duplikat")
		}
		addresses[address] = true
		pub, err := hex.DecodeString(v.PublicKey)
		if err != nil || len(pub) != ed25519.PublicKeySize {
			return errors.New("public key validator tidak valid")
		}
		key := hex.EncodeToString(pub)
		if publicKeys[key] {
			return errors.New("public key validator duplikat")
		}
		publicKeys[key] = true
		if !strings.EqualFold(AddressFromPublicKey(ed25519.PublicKey(pub)), address) {
			return errors.New("alamat dan public key validator tidak cocok")
		}
		if v.Stake < 0 {
			return errors.New("stake validator tidak boleh negatif")
		}
		if v.Active {
			activeCount++
		}
	}
	if activeCount == 0 {
		return errors.New("tidak ada validator aktif")
	}
	return nil
}

func VoteDigest(v ConsensusVote) (string, error) {
	message, err := v.SigningBytes()
	if err != nil {
		return "", err
	}
	sum := sha256.Sum256(message)
	return hex.EncodeToString(sum[:]), nil
}
