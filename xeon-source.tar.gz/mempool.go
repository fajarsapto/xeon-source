package main

import (
	"errors"
	"strconv"
	"sync"
)

const MaxPendingTransactions = 10000

var (
	ErrMempoolFull      = errors.New("mempool penuh")
	ErrDuplicateNonce   = errors.New("transaksi dengan nonce tersebut sudah ada")
	ErrInvalidPendingTx = errors.New("transaksi tidak valid")
)

type Mempool struct {
	mu           sync.RWMutex
	transactions []Transaction
	nonces       map[string]bool
}

func NewMempool() *Mempool {
	return &Mempool{
		transactions: make([]Transaction, 0),
		nonces:       make(map[string]bool),
	}
}

func pendingKey(tx Transaction) string {
	return tx.From + ":" + strconv.FormatUint(tx.Nonce, 10)
}

func (m *Mempool) Add(tx Transaction) error {
	if err := tx.Verify(LedgerChainID); err != nil {
		return err
	}

	m.mu.Lock()
	defer m.mu.Unlock()

	key := pendingKey(tx)
	if m.nonces[key] {
		return ErrDuplicateNonce
	}
	if len(m.transactions) >= MaxPendingTransactions {
		return ErrMempoolFull
	}

	m.transactions = append(m.transactions, tx)
	m.nonces[key] = true
	return nil
}

func (m *Mempool) Pending() []Transaction {
	m.mu.RLock()
	defer m.mu.RUnlock()

	result := make([]Transaction, len(m.transactions))
	copy(result, m.transactions)
	return result
}

func (m *Mempool) RemoveIncluded(included []Transaction) {
	m.mu.Lock()
	defer m.mu.Unlock()

	removed := make(map[string]bool, len(included))
	for _, tx := range included {
		removed[pendingKey(tx)] = true
	}

	remaining := make([]Transaction, 0, len(m.transactions))
	for _, tx := range m.transactions {
		key := pendingKey(tx)
		if removed[key] {
			delete(m.nonces, key)
			continue
		}
		remaining = append(remaining, tx)
	}
	m.transactions = remaining
}

func (m *Mempool) Len() int {
	m.mu.RLock()
	defer m.mu.RUnlock()
	return len(m.transactions)
}
