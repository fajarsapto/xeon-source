package main

import (
	"crypto/ed25519"
	"encoding/hex"
	"errors"
	"sort"
	"strings"
)

type FinalityCertificate struct {
	ChainID   string          `json:"chain_id"`
	Height    uint64          `json:"height"`
	Round     uint64          `json:"round"`
	BlockHash string          `json:"block_hash"`
	Votes     []ConsensusVote `json:"votes"`
}

func BuildFinalityCertificate(chainID string, height, round uint64, blockHash string, votes []ConsensusVote, validators []Validator) (*FinalityCertificate, error) {
	if strings.TrimSpace(chainID) == "" || height == 0 {
		return nil, errors.New("chain ID atau height tidak valid")
	}
	blockHash = strings.ToLower(strings.TrimSpace(blockHash))
	if len(blockHash) != 64 {
		return nil, errors.New("block hash harus 32 byte dalam format hex")
	}
	if _, err := hex.DecodeString(blockHash); err != nil {
		return nil, errors.New("block hash bukan hex valid")
	}
	if err := ValidateValidatorSet(validators); err != nil {
		return nil, err
	}
	active := 0
	for _, v := range validators {
		if v.Active {
			active++
		}
	}
	quorum, err := BFTQuorum(active)
	if err != nil {
		return nil, err
	}
	seen := make(map[string]bool)
	accepted := make([]ConsensusVote, 0, len(votes))
	for _, vote := range votes {
		if vote.ChainID != chainID || vote.Height != height || vote.Round != round || vote.Type != VotePrecommit || strings.ToLower(vote.BlockHash) != blockHash {
			continue
		}
		address := strings.ToLower(vote.Validator)
		if seen[address] {
			return nil, errors.New("sertifikat berisi vote validator duplikat")
		}
		if err := vote.Verify(chainID, validators); err != nil {
			return nil, err
		}
		seen[address] = true
		accepted = append(accepted, vote)
	}
	if len(accepted) < quorum {
		return nil, errors.New("jumlah precommit valid belum memenuhi quorum")
	}
	sort.Slice(accepted, func(i, j int) bool {
		return strings.ToLower(accepted[i].Validator) < strings.ToLower(accepted[j].Validator)
	})
	return &FinalityCertificate{ChainID: chainID, Height: height, Round: round, BlockHash: blockHash, Votes: accepted}, nil
}
func (c FinalityCertificate) Verify(validators []Validator) error {
	if strings.TrimSpace(c.ChainID) == "" || c.Height == 0 {
		return errors.New("identitas sertifikat tidak valid")
	}
	blockHash := strings.ToLower(strings.TrimSpace(c.BlockHash))
	if len(blockHash) != 64 {
		return errors.New("block hash sertifikat tidak valid")
	}
	if _, err := hex.DecodeString(blockHash); err != nil {
		return errors.New("block hash sertifikat bukan hex valid")
	}
	if err := ValidateValidatorSet(validators); err != nil {
		return err
	}
	active := 0
	for _, v := range validators {
		if v.Active {
			active++
		}
	}
	quorum, err := BFTQuorum(active)
	if err != nil {
		return err
	}
	seen := make(map[string]bool)
	for _, vote := range c.Votes {
		if vote.ChainID != c.ChainID || vote.Height != c.Height || vote.Round != c.Round || vote.Type != VotePrecommit || strings.ToLower(vote.BlockHash) != blockHash {
			return errors.New("vote tidak cocok dengan sertifikat")
		}
		address := strings.ToLower(vote.Validator)
		if seen[address] {
			return errors.New("validator duplikat dalam sertifikat")
		}
		if err := vote.Verify(c.ChainID, validators); err != nil {
			return err
		}
		seen[address] = true
	}
	if len(seen) < quorum {
		return errors.New("sertifikat tidak memenuhi quorum")
	}
	return nil
}
func validEd25519PublicKey(encoded string) bool {
	key, err := hex.DecodeString(encoded)
	return err == nil && len(key) == ed25519.PublicKeySize
}
