package main

import (
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"strings"
)

const (
	AddressLength = 40
	MaxTxDataSize = 4096
)

type Transaction struct {
	ChainID   string `json:"chain_id"`
	From      string `json:"from"`
	To        string `json:"to"`
	Amount    int64  `json:"amount"`
	Nonce     uint64 `json:"nonce"`
	PublicKey string `json:"public_key"`
	Signature string `json:"signature"`
}

type transactionPayload struct {
	ChainID string `json:"chain_id"`
	From    string `json:"from"`
	To      string `json:"to"`
	Amount  int64  `json:"amount"`
	Nonce   uint64 `json:"nonce"`
}

func AddressFromPublicKey(publicKey ed25519.PublicKey) string {
	hash := sha256.Sum256(publicKey)
	return hex.EncodeToString(hash[len(hash)-20:])
}

func (tx Transaction) payload() transactionPayload {
	return transactionPayload{
		ChainID: tx.ChainID,
		From:    strings.ToLower(tx.From),
		To:      strings.ToLower(tx.To),
		Amount:  tx.Amount,
		Nonce:   tx.Nonce,
	}
}

func (tx Transaction) SigningBytes() ([]byte, error) {
	payload, err := json.Marshal(tx.payload())
	if err != nil {
		return nil, err
	}

	return payload, nil
}

func (tx *Transaction) Sign(privateKey ed25519.PrivateKey) error {
	if len(privateKey) != ed25519.PrivateKeySize {
		return errors.New("private key Ed25519 tidak valid")
	}

	publicKey := privateKey.Public().(ed25519.PublicKey)

	tx.PublicKey = hex.EncodeToString(publicKey)
	tx.From = AddressFromPublicKey(publicKey)

	message, err := tx.SigningBytes()
	if err != nil {
		return err
	}

	signature := ed25519.Sign(privateKey, message)
	tx.Signature = hex.EncodeToString(signature)

	return nil
}

func (tx Transaction) Verify(expectedChainID string) error {
	if tx.ChainID != expectedChainID {
		return errors.New("chain ID tidak sesuai")
	}

	if tx.Amount <= 0 {
		return errors.New("jumlah transaksi harus lebih dari nol")
	}

	if tx.Nonce == 0 {
		return errors.New("nonce harus lebih dari nol")
	}

	if len(tx.From) != AddressLength || len(tx.To) != AddressLength {
		return errors.New("alamat harus terdiri dari 40 karakter hex")
	}

	fromBytes, err := hex.DecodeString(tx.From)
	if err != nil || len(fromBytes) != 20 {
		return errors.New("alamat pengirim tidak valid")
	}

	toBytes, err := hex.DecodeString(tx.To)
	if err != nil || len(toBytes) != 20 {
		return errors.New("alamat penerima tidak valid")
	}

	if strings.EqualFold(tx.From, tx.To) {
		return errors.New("pengirim dan penerima tidak boleh sama")
	}

	publicKeyBytes, err := hex.DecodeString(tx.PublicKey)
	if err != nil || len(publicKeyBytes) != ed25519.PublicKeySize {
		return errors.New("public key tidak valid")
	}

	publicKey := ed25519.PublicKey(publicKeyBytes)

	expectedAddress := AddressFromPublicKey(publicKey)
	if !strings.EqualFold(tx.From, expectedAddress) {
		return errors.New("public key tidak cocok dengan alamat pengirim")
	}

	signature, err := hex.DecodeString(tx.Signature)
	if err != nil || len(signature) != ed25519.SignatureSize {
		return errors.New("signature tidak valid")
	}

	message, err := tx.SigningBytes()
	if err != nil {
		return err
	}

	if !ed25519.Verify(publicKey, message, signature) {
		return errors.New("verifikasi tanda tangan gagal")
	}

	return nil
}
