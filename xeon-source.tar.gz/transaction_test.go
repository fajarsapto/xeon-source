package main

import (
	"crypto/ed25519"
	"crypto/rand"
	"strings"
	"testing"
)

func makeTestTransaction(t *testing.T) (Transaction, ed25519.PrivateKey) {
	t.Helper()

	_, privateKey, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}

	_, receiverPrivate, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}

	receiverPublic := receiverPrivate.Public().(ed25519.PublicKey)

	tx := Transaction{
		ChainID: "xeon-v2-local",
		To:      AddressFromPublicKey(receiverPublic),
		Amount:  100,
		Nonce:   1,
	}

	if err := tx.Sign(privateKey); err != nil {
		t.Fatal(err)
	}

	return tx, privateKey
}

func TestTransactionSignature(t *testing.T) {
	tx, _ := makeTestTransaction(t)

	if err := tx.Verify("xeon-v2-local"); err != nil {
		t.Fatalf("transaksi yang sah ditolak: %v", err)
	}
}

func TestRejectWrongChain(t *testing.T) {
	tx, _ := makeTestTransaction(t)

	if err := tx.Verify("xeon-mainnet"); err == nil {
		t.Fatal("transaksi dari chain lain seharusnya ditolak")
	}
}

func TestRejectTamperedAmount(t *testing.T) {
	tx, _ := makeTestTransaction(t)
	tx.Amount++

	if err := tx.Verify("xeon-v2-local"); err == nil {
		t.Fatal("perubahan jumlah seharusnya membatalkan signature")
	}
}

func TestRejectTamperedReceiver(t *testing.T) {
	tx, _ := makeTestTransaction(t)
	tx.To = strings.Repeat("a", 40)

	if err := tx.Verify("xeon-v2-local"); err == nil {
		t.Fatal("perubahan penerima seharusnya membatalkan signature")
	}
}

func TestRejectZeroAmount(t *testing.T) {
	tx, _ := makeTestTransaction(t)
	tx.Amount = 0

	if err := tx.Verify("xeon-v2-local"); err == nil {
		t.Fatal("jumlah nol seharusnya ditolak")
	}
}

func TestRejectInvalidNonce(t *testing.T) {
	tx, _ := makeTestTransaction(t)
	tx.Nonce = 0

	if err := tx.Verify("xeon-v2-local"); err == nil {
		t.Fatal("nonce nol seharusnya ditolak")
	}
}

func TestRejectInvalidSignature(t *testing.T) {
	tx, _ := makeTestTransaction(t)

	tx.Signature = strings.Repeat("0", 128)

	if err := tx.Verify("xeon-v2-local"); err == nil {
		t.Fatal("signature palsu seharusnya ditolak")
	}
}

func TestRejectWrongSenderKey(t *testing.T) {
	tx, _ := makeTestTransaction(t)

	_, anotherPrivate, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}

	tx.PublicKey = strings.ToLower(
		strings.Repeat("ab", ed25519.PublicKeySize),
	)

	if err := tx.Verify("xeon-v2-local"); err == nil {
		t.Fatal("public key yang tidak cocok seharusnya ditolak")
	}

	_ = anotherPrivate
}
