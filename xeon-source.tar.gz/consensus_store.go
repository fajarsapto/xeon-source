package main

import (
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

const ConsensusStoreVersion = 1

type ConsensusStore struct {
	Version       int            `json:"version"`
	ChainID       string         `json:"chain_id"`
	Height        uint64         `json:"height"`
	Round         uint64         `json:"round"`
	Phase         ConsensusPhase `json:"phase"`
	Validators    []Validator    `json:"validators"`
	FinalizedHash string         `json:"finalized_hash,omitempty"`
}

func ValidateConsensusStore(s ConsensusStore) error {
	if s.Version != ConsensusStoreVersion {
		return fmt.Errorf("versi consensus store tidak didukung: %d", s.Version)
	}
	if strings.TrimSpace(s.ChainID) == "" {
		return errors.New("chain ID consensus store kosong")
	}
	if s.Height == 0 {
		return errors.New("height consensus store harus lebih besar dari nol")
	}
	switch s.Phase {
	case PhasePropose, PhasePrevote, PhasePrecommit, PhaseFinalized:
	default:
		return errors.New("fase consensus store tidak valid")
	}
	if err := ValidateValidatorSet(s.Validators); err != nil {
		return err
	}
	if s.Phase == PhaseFinalized {
		if len(s.FinalizedHash) != 64 {
			return errors.New("finalized hash tidak valid")
		}
		if _, err := hex.DecodeString(s.FinalizedHash); err != nil {
			return errors.New("finalized hash bukan hex valid")
		}
	} else if s.FinalizedHash != "" {
		return errors.New("finalized hash harus kosong sebelum fase final")
	}
	return nil
}
func SaveConsensusStore(path string, s ConsensusStore) error {
	if strings.TrimSpace(path) == "" {
		return errors.New("path consensus store kosong")
	}
	if err := ValidateConsensusStore(s); err != nil {
		return err
	}
	data, err := json.MarshalIndent(s, "", "  ")
	if err != nil {
		return err
	}
	dir := filepath.Dir(path)
	if err := os.MkdirAll(dir, 0700); err != nil {
		return err
	}
	tmp, err := os.CreateTemp(dir, ".consensus-store-*.tmp")
	if err != nil {
		return err
	}
	tmpName := tmp.Name()
	defer os.Remove(tmpName)
	if err := tmp.Chmod(0600); err != nil {
		_ = tmp.Close()
		return err
	}
	if _, err := tmp.Write(data); err != nil {
		_ = tmp.Close()
		return err
	}
	if err := tmp.Sync(); err != nil {
		_ = tmp.Close()
		return err
	}
	if err := tmp.Close(); err != nil {
		return err
	}
	if err := os.Rename(tmpName, path); err != nil {
		return err
	}
	if d, err := os.Open(dir); err == nil {
		_ = d.Sync()
		_ = d.Close()
	}
	return nil
}
func LoadConsensusStore(path, expectedChainID string) (ConsensusStore, error) {
	var s ConsensusStore
	if strings.TrimSpace(expectedChainID) == "" {
		return s, errors.New("expected chain ID kosong")
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return s, err
	}
	if err := json.Unmarshal(data, &s); err != nil {
		return s, err
	}
	if err := ValidateConsensusStore(s); err != nil {
		return s, err
	}
	if s.ChainID != expectedChainID {
		return s, errors.New("chain ID consensus store tidak sesuai")
	}
	return s, nil
}
