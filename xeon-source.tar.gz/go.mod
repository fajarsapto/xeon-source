module xeon-v2

go 1.24
