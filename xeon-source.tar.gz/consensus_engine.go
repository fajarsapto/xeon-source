package main

import (
	"errors"
	"fmt"
	"strings"
	"sync"
)

var (
	ErrConsensusHeight      = errors.New("height konsensus tidak sesuai")
	ErrConsensusRound       = errors.New("round konsensus tidak sesuai")
	ErrDuplicateVote        = errors.New("validator sudah memberikan vote untuk tahap ini")
	ErrConflictingVote      = errors.New("validator memberikan vote yang bertentangan")
	ErrBlockNotPrecommitted = errors.New("blok belum memperoleh quorum precommit")
)

type ConsensusPhase string

const (
	PhasePropose   ConsensusPhase = "PROPOSE"
	PhasePrevote   ConsensusPhase = "PREVOTE"
	PhasePrecommit ConsensusPhase = "PRECOMMIT"
	PhaseFinalized ConsensusPhase = "FINALIZED"
)

type voteRecord struct {
	BlockHash string
	Vote      ConsensusVote
}
type ConsensusEngine struct {
	mu            sync.Mutex
	chainID       string
	height        uint64
	round         uint64
	phase         ConsensusPhase
	validators    []Validator
	prevotes      map[string]voteRecord
	precommits    map[string]voteRecord
	finalizedHash string
	lockedHash    string
}

func NewConsensusEngine(chainID string, height uint64, validators []Validator) (*ConsensusEngine, error) {
	if strings.TrimSpace(chainID) == "" {
		return nil, errors.New("chain ID kosong")
	}
	if err := ValidateValidatorSet(validators); err != nil {
		return nil, err
	}
	active := make([]Validator, 0, len(validators))
	for _, v := range validators {
		if v.Active {
			active = append(active, v)
		}
	}
	return &ConsensusEngine{chainID: chainID, height: height + 1, phase: PhasePropose, validators: active, prevotes: make(map[string]voteRecord), precommits: make(map[string]voteRecord)}, nil
}
func (e *ConsensusEngine) State() (uint64, uint64, ConsensusPhase, string) {
	e.mu.Lock()
	defer e.mu.Unlock()
	return e.height, e.round, e.phase, e.finalizedHash
}
func (e *ConsensusEngine) Quorum() int {
	e.mu.Lock()
	defer e.mu.Unlock()
	q, err := BFTQuorum(len(e.validators))
	if err != nil {
		return 0
	}
	return q
}
func (e *ConsensusEngine) BeginPrevote() error {
	e.mu.Lock()
	defer e.mu.Unlock()
	if e.lockedHash != "" {
		return errors.New("lock blok masih aktif; pemulihan lock lintas-round belum tersedia")
	}
	if e.phase != PhasePropose {
		return fmt.Errorf("tidak dapat memulai prevote dari fase %s", e.phase)
	}
	e.phase = PhasePrevote
	return nil
}

func (e *ConsensusEngine) SubmitVote(v ConsensusVote) error {
	e.mu.Lock()
	defer e.mu.Unlock()
	if e.phase == PhaseFinalized {
		return errors.New("height sudah final")
	}
	if v.Height != e.height {
		return ErrConsensusHeight
	}
	if v.Round != e.round {
		return ErrConsensusRound
	}
	if v.ChainID != e.chainID {
		return errors.New("chain ID vote tidak sesuai")
	}
	if err := v.Verify(e.chainID, e.validators); err != nil {
		return err
	}
	address, hash := strings.ToLower(v.Validator), strings.ToLower(v.BlockHash)
	switch v.Type {
	case VotePrevote:
		if e.phase != PhasePrevote {
			return errors.New("prevote tidak diterima pada fase ini")
		}
		if old, ok := e.prevotes[address]; ok {
			if old.BlockHash != hash {
				return ErrConflictingVote
			}
			return ErrDuplicateVote
		}
		e.prevotes[address] = voteRecord{BlockHash: hash, Vote: v}
	case VotePrecommit:
		if e.phase != PhasePrecommit {
			return errors.New("precommit tidak diterima sebelum fase precommit")
		}
		if hash != e.lockedHash {
			return errors.New("precommit hash tidak sesuai dengan hash yang dikunci")
		}
		if old, ok := e.precommits[address]; ok {
			if old.BlockHash != hash {
				return ErrConflictingVote
			}
			return ErrDuplicateVote
		}
		e.precommits[address] = voteRecord{BlockHash: hash, Vote: v}
	default:
		return errors.New("jenis vote tidak didukung")
	}
	return nil
}
func countVotes(records map[string]voteRecord, blockHash string) int {
	n := 0
	blockHash = strings.ToLower(blockHash)
	for _, v := range records {
		if v.BlockHash == blockHash {
			n++
		}
	}
	return n
}
func (e *ConsensusEngine) HasPrevoteQuorum(hash string) bool {
	e.mu.Lock()
	defer e.mu.Unlock()
	q, err := BFTQuorum(len(e.validators))
	return err == nil && countVotes(e.prevotes, hash) >= q
}
func (e *ConsensusEngine) BeginPrecommit(hash string) error {
	e.mu.Lock()
	defer e.mu.Unlock()
	if e.phase != PhasePrevote {
		return errors.New("fase harus PREVOTE")
	}
	q, err := BFTQuorum(len(e.validators))
	if err != nil {
		return err
	}
	if countVotes(e.prevotes, hash) < q {
		return errors.New("quorum prevote belum tercapai")
	}
	e.lockedHash = strings.ToLower(hash)
	e.phase = PhasePrecommit
	return nil
}
func (e *ConsensusEngine) Finalize(hash string) error {
	e.mu.Lock()
	defer e.mu.Unlock()
	if e.phase != PhasePrecommit {
		return ErrBlockNotPrecommitted
	}
	if strings.ToLower(hash) != e.lockedHash {
		return errors.New("hash finalisasi berbeda dari hash prevote yang dikunci")
	}
	q, err := BFTQuorum(len(e.validators))
	if err != nil {
		return err
	}
	if countVotes(e.precommits, hash) < q {
		return errors.New("quorum precommit belum tercapai")
	}
	e.finalizedHash = strings.ToLower(hash)
	e.phase = PhaseFinalized
	return nil
}
func (e *ConsensusEngine) NextHeight() error {
	e.mu.Lock()
	defer e.mu.Unlock()
	if e.phase != PhaseFinalized {
		return errors.New("height saat ini belum final")
	}
	e.height++
	e.round = 0
	e.phase = PhasePropose
	e.prevotes = make(map[string]voteRecord)
	e.precommits = make(map[string]voteRecord)
	e.finalizedHash = ""
	e.lockedHash = ""
	return nil
}
func (e *ConsensusEngine) NextRound() error {
	e.mu.Lock()
	defer e.mu.Unlock()
	if e.phase == PhaseFinalized {
		return errors.New("height sudah final")
	}
	if e.lockedHash != "" {
		return errors.New("lock aktif; round baru ditolak")
	}
	e.round++
	e.phase = PhasePropose
	e.prevotes = make(map[string]voteRecord)
	e.precommits = make(map[string]voteRecord)
	return nil
}
