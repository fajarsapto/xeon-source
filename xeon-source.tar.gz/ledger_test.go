package main

import (
	"crypto/ed25519"
	"crypto/rand"
	"path/filepath"
	"testing"
)

func createTestKey(t *testing.T) (ed25519.PublicKey, ed25519.PrivateKey) {
	t.Helper()

	publicKey, privateKey, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}

	return publicKey, privateKey
}

func createSignedTx(
	t *testing.T,
	privateKey ed25519.PrivateKey,
	receiver ed25519.PublicKey,
	amount int64,
	nonce uint64,
) Transaction {
	t.Helper()

	tx := Transaction{
		ChainID: LedgerChainID,
		To:      AddressFromPublicKey(receiver),
		Amount:  amount,
		Nonce:   nonce,
	}

	if err := tx.Sign(privateKey); err != nil {
		t.Fatal(err)
	}

	return tx
}

func TestLedgerGenesisBalance(t *testing.T) {
	genesisPublic, genesisPrivate := createTestKey(t)
	path := filepath.Join(t.TempDir(), "ledger.json")

	ledger, err := NewLedger(path, AddressFromPublicKey(genesisPublic))
	if err != nil {
		t.Fatal(err)
	}

	account, err := ledger.AccountInfo(AddressFromPublicKey(genesisPublic))
	if err != nil {
		t.Fatal(err)
	}

	if account.Balance != GenesisAllocation {
		t.Fatalf("saldo Genesis salah: %d", account.Balance)
	}

	if len(genesisPrivate) != ed25519.PrivateKeySize {
		t.Fatal("private key test tidak valid")
	}
}

func TestLedgerTransfer(t *testing.T) {
	genesisPublic, genesisPrivate := createTestKey(t)
	receiverPublic, _ := createTestKey(t)

	ledger, err := NewLedger(
		filepath.Join(t.TempDir(), "ledger.json"),
		AddressFromPublicKey(genesisPublic),
	)
	if err != nil {
		t.Fatal(err)
	}

	tx := createSignedTx(t, genesisPrivate, receiverPublic, 100, 1)

	if err := ledger.ApplyTransaction(tx); err != nil {
		t.Fatal(err)
	}

	sender, _ := ledger.AccountInfo(AddressFromPublicKey(genesisPublic))
	receiver, _ := ledger.AccountInfo(AddressFromPublicKey(receiverPublic))

	if sender.Balance != GenesisAllocation-100 {
		t.Fatalf("saldo pengirim salah: %d", sender.Balance)
	}

	if receiver.Balance != 100 {
		t.Fatalf("saldo penerima salah: %d", receiver.Balance)
	}

	if sender.Nonce != 1 {
		t.Fatalf("nonce salah: %d", sender.Nonce)
	}
}

func TestRejectDoubleSpendReplay(t *testing.T) {
	genesisPublic, genesisPrivate := createTestKey(t)
	receiverPublic, _ := createTestKey(t)

	ledger, err := NewLedger(
		filepath.Join(t.TempDir(), "ledger.json"),
		AddressFromPublicKey(genesisPublic),
	)
	if err != nil {
		t.Fatal(err)
	}

	tx := createSignedTx(t, genesisPrivate, receiverPublic, 100, 1)

	if err := ledger.ApplyTransaction(tx); err != nil {
		t.Fatal(err)
	}

	if err := ledger.ApplyTransaction(tx); err == nil {
		t.Fatal("transaksi yang sama tidak boleh diproses dua kali")
	}
}

func TestRejectOverspend(t *testing.T) {
	genesisPublic, genesisPrivate := createTestKey(t)
	receiverPublic, _ := createTestKey(t)

	ledger, err := NewLedger(
		filepath.Join(t.TempDir(), "ledger.json"),
		AddressFromPublicKey(genesisPublic),
	)
	if err != nil {
		t.Fatal(err)
	}

	tx := createSignedTx(
		t,
		genesisPrivate,
		receiverPublic,
		MaxSupply,
		1,
	)

	if err := ledger.ApplyTransaction(tx); err == nil {
		t.Fatal("transaksi melebihi saldo harus ditolak")
	}
}

func TestRejectNonceGap(t *testing.T) {
	genesisPublic, genesisPrivate := createTestKey(t)
	receiverPublic, _ := createTestKey(t)

	ledger, err := NewLedger(
		filepath.Join(t.TempDir(), "ledger.json"),
		AddressFromPublicKey(genesisPublic),
	)
	if err != nil {
		t.Fatal(err)
	}

	tx := createSignedTx(t, genesisPrivate, receiverPublic, 100, 2)

	if err := ledger.ApplyTransaction(tx); err == nil {
		t.Fatal("nonce yang melompat harus ditolak")
	}
}

func TestLedgerPersistence(t *testing.T) {
	genesisPublic, genesisPrivate := createTestKey(t)
	receiverPublic, _ := createTestKey(t)

	path := filepath.Join(t.TempDir(), "ledger.json")
	genesisAddress := AddressFromPublicKey(genesisPublic)

	ledger, err := NewLedger(path, genesisAddress)
	if err != nil {
		t.Fatal(err)
	}

	tx := createSignedTx(t, genesisPrivate, receiverPublic, 100, 1)
	if err := ledger.ApplyTransaction(tx); err != nil {
		t.Fatal(err)
	}

	reloaded, err := NewLedger(path, genesisAddress)
	if err != nil {
		t.Fatal(err)
	}

	account, err := reloaded.AccountInfo(AddressFromPublicKey(receiverPublic))
	if err != nil {
		t.Fatal(err)
	}

	if account.Balance != 100 {
		t.Fatalf("saldo tidak bertahan setelah reload: %d", account.Balance)
	}
}
