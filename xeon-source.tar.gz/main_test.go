package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestGenesisBlock(t *testing.T) {
	bc := NewBlockchain()

	if len(bc.Blocks) != 1 {
		t.Fatal("Genesis block tidak terbentuk")
	}

	if bc.Blocks[0].Height != 0 {
		t.Fatal("Height genesis harus 0")
	}

	if !bc.Validate() {
		t.Fatal("Genesis block tidak valid")
	}
}

func TestSupplyAllocation(t *testing.T) {
	total := GenesisAllocation + EmergencyReserve + RewardReserve

	if total != MaxSupply {
		t.Fatalf("Alokasi %d tidak sama dengan suplai maksimum %d", total, MaxSupply)
	}
}

func TestAddBlock(t *testing.T) {
	bc := NewBlockchain()

	block, err := bc.AddBlock("TEST_TRANSACTION")
	if err == nil {
		t.Fatal("penambahan blok tanpa jalur penyimpanan seharusnya gagal")
	}
	_ = block

	path := filepath.Join(t.TempDir(), "blockchain.json")
	bc.DataPath = path

	block, err = bc.AddBlock("TEST_TRANSACTION")
	if err != nil {
		t.Fatalf("gagal menambahkan blok: %v", err)
	}

	if block.Height != 1 {
		t.Fatal("Height blok baru harus 1")
	}

	if !bc.Validate() {
		t.Fatal("Blockchain tidak valid setelah penambahan blok")
	}
}

func TestPersistentReload(t *testing.T) {
	path := filepath.Join(t.TempDir(), "blockchain.json")

	bc, err := LoadBlockchain(path)
	if err != nil {
		t.Fatal(err)
	}

	_, err = bc.AddBlock("BLOCK_1")
	if err != nil {
		t.Fatal(err)
	}

	_, err = bc.AddBlock("BLOCK_2")
	if err != nil {
		t.Fatal(err)
	}

	reloaded, err := LoadBlockchain(path)
	if err != nil {
		t.Fatal(err)
	}

	if len(reloaded.Blocks) != 3 {
		t.Fatalf("mengharapkan 3 blok, mendapatkan %d", len(reloaded.Blocks))
	}

	if !reloaded.Validate() {
		t.Fatal("Blockchain tidak valid setelah dimuat ulang")
	}
}

func TestTamperedBlockRejected(t *testing.T) {
	path := filepath.Join(t.TempDir(), "blockchain.json")

	bc, err := LoadBlockchain(path)
	if err != nil {
		t.Fatal(err)
	}

	_, err = bc.AddBlock("DATA_ASLI")
	if err != nil {
		t.Fatal(err)
	}

	bc.mu.Lock()
	bc.Blocks[1].Data = "DATA_DIUBAH"
	bc.mu.Unlock()

	if bc.Validate() {
		t.Fatal("Perubahan data blok seharusnya terdeteksi")
	}

	if err := os.WriteFile(path, []byte(`{"blocks":[{"height":0}]}`), 0600); err != nil {
		t.Fatal(err)
	}

	if _, err := LoadBlockchain(path); err == nil {
		t.Fatal("file blockchain rusak seharusnya ditolak")
	}
}
