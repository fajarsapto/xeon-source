package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"sync"
	"time"
)

const (
	ChainName = "Xeon Blockchain"
	Symbol    = "XEON"

	MaxSupply         int64 = 19_000_000
	GenesisAllocation int64 = 9_500_000
	EmergencyReserve  int64 = 3_800_000
	RewardReserve     int64 = 5_700_000
	BlockReward       int64 = 80

	DefaultDataPath = "./data/blockchain.json"
)

type Block struct {
	Height    uint64 `json:"height"`
	Timestamp int64  `json:"timestamp"`
	Previous  string `json:"previous_hash"`
	Data      string `json:"data"`
	Hash      string `json:"hash"`
}

type Blockchain struct {
	mu       sync.RWMutex
	Blocks   []Block `json:"blocks"`
	DataPath string  `json:"-"`
}

type Status struct {
	Name              string `json:"name"`
	Symbol            string `json:"symbol"`
	Network           string `json:"network"`
	Height            uint64 `json:"height"`
	LatestHash        string `json:"latest_hash"`
	MaxSupply         int64  `json:"max_supply"`
	GenesisAllocation int64  `json:"genesis_allocation"`
	EmergencyReserve  int64  `json:"emergency_reserve"`
	RewardReserve     int64  `json:"reward_reserve"`
	BlockReward       int64  `json:"block_reward"`
	Consensus         string `json:"consensus"`
	NetworkStatus     string `json:"network_status"`
}

func calculateHash(b Block) string {
	payload := struct {
		Height    uint64 `json:"height"`
		Timestamp int64  `json:"timestamp"`
		Previous  string `json:"previous_hash"`
		Data      string `json:"data"`
	}{
		Height:    b.Height,
		Timestamp: b.Timestamp,
		Previous:  b.Previous,
		Data:      b.Data,
	}

	raw, err := json.Marshal(payload)
	if err != nil {
		panic(err)
	}

	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:])
}

func newGenesis() Block {
	b := Block{
		Height:    0,
		Timestamp: time.Now().Unix(),
		Previous:  "0",
		Data:      "XEON_GENESIS_V1",
	}
	b.Hash = calculateHash(b)
	return b
}

func NewBlockchain() *Blockchain {
	return &Blockchain{
		Blocks: []Block{newGenesis()},
	}
}

// Save menggunakan file sementara dan rename agar file utama tidak
// tertinggal dalam keadaan setengah tertulis jika proses terganggu.
func (bc *Blockchain) saveLocked() error {
	if bc.DataPath == "" {
		return errors.New("jalur penyimpanan belum ditentukan")
	}

	if err := os.MkdirAll(filepath.Dir(bc.DataPath), 0700); err != nil {
		return err
	}

	raw, err := json.MarshalIndent(bc, "", "  ")
	if err != nil {
		return err
	}

	tmp := bc.DataPath + ".tmp"

	if err := os.WriteFile(tmp, raw, 0600); err != nil {
		return err
	}

	f, err := os.OpenFile(tmp, os.O_RDWR, 0600)
	if err != nil {
		return err
	}

	if err := f.Sync(); err != nil {
		f.Close()
		return err
	}

	if err := f.Close(); err != nil {
		return err
	}

	if err := os.Rename(tmp, bc.DataPath); err != nil {
		return err
	}

	return nil
}

func (bc *Blockchain) Save() error {
	bc.mu.Lock()
	defer bc.mu.Unlock()
	return bc.saveLocked()
}

func LoadBlockchain(path string) (*Blockchain, error) {
	bc := &Blockchain{DataPath: path}

	raw, err := os.ReadFile(path)
	if err != nil {
		if !os.IsNotExist(err) {
			return nil, err
		}

		bc.Blocks = []Block{newGenesis()}

		if err := bc.Save(); err != nil {
			return nil, err
		}

		return bc, nil
	}

	if err := json.Unmarshal(raw, bc); err != nil {
		return nil, fmt.Errorf("file blockchain rusak: %w", err)
	}

	bc.DataPath = path

	if !bc.Validate() {
		return nil, errors.New("validasi blockchain gagal; data tidak dimuat")
	}

	return bc, nil
}

func (bc *Blockchain) AddBlock(data string) (Block, error) {
	bc.mu.Lock()
	defer bc.mu.Unlock()

	if len(bc.Blocks) == 0 {
		return Block{}, errors.New("blockchain kosong")
	}

	previous := bc.Blocks[len(bc.Blocks)-1]

	block := Block{
		Height:    previous.Height + 1,
		Timestamp: time.Now().Unix(),
		Previous:  previous.Hash,
		Data:      data,
	}
	block.Hash = calculateHash(block)

	// Tambahkan sementara; rollback jika penyimpanan gagal.
	bc.Blocks = append(bc.Blocks, block)

	if err := bc.saveLocked(); err != nil {
		bc.Blocks = bc.Blocks[:len(bc.Blocks)-1]
		return Block{}, err
	}

	return block, nil
}

func (bc *Blockchain) Validate() bool {
	bc.mu.RLock()
	defer bc.mu.RUnlock()

	if len(bc.Blocks) == 0 {
		return false
	}

	for i, block := range bc.Blocks {
		if calculateHash(block) != block.Hash {
			return false
		}

		if i == 0 {
			if block.Height != 0 || block.Previous != "0" {
				return false
			}
			continue
		}

		previous := bc.Blocks[i-1]

		if block.Height != previous.Height+1 {
			return false
		}

		if block.Previous != previous.Hash {
			return false
		}
	}

	return true
}

func (bc *Blockchain) Status() Status {
	bc.mu.RLock()
	defer bc.mu.RUnlock()

	latest := bc.Blocks[len(bc.Blocks)-1]

	return Status{
		Name:              ChainName,
		Symbol:            Symbol,
		Network:           "xeon-v2-local",
		Height:            latest.Height,
		LatestHash:        latest.Hash,
		MaxSupply:         MaxSupply,
		GenesisAllocation: GenesisAllocation,
		EmergencyReserve:  EmergencyReserve,
		RewardReserve:     RewardReserve,
		BlockReward:       BlockReward,
		Consensus:         "BFT (belum diaktifkan)",
		NetworkStatus:     "LOCAL_DEVELOPMENT",
	}
}

func writeJSON(w http.ResponseWriter, status int, data any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(data)
}

func main() {
	if GenesisAllocation+EmergencyReserve+RewardReserve != MaxSupply {
		log.Fatal("Konfigurasi suplai XEON tidak valid")
	}

	dataPath := os.Getenv("XEON_DATA")
	if dataPath == "" {
		dataPath = DefaultDataPath
	}

	chain, err := LoadBlockchain(dataPath)
	if err != nil {
		log.Fatalf("Gagal memuat blockchain: %v", err)
	}

	mux := http.NewServeMux()

	mempool := NewMempool()
	ledgerPath := os.Getenv("XEON_LEDGER")
	if ledgerPath == "" {
		ledgerPath = "./data/ledger.json"
	}
	if err := os.MkdirAll(filepath.Dir(ledgerPath), 0700); err != nil {
		log.Fatal(err)
	}
	genesisAddress := os.Getenv("XEON_GENESIS_ADDRESS")
	if genesisAddress == "" {
		genesisAddress = "2843215f04d39b96b0fcc1ad668fd19161d828e1"
	}
	ledger, err := NewLedger(ledgerPath, genesisAddress)
	if err != nil {
		log.Fatalf("gagal menginisialisasi ledger: %v", err)
	}

	mux.HandleFunc("/transactions/pending", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			w.Header().Set("Allow", http.MethodGet)
			writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "method tidak diizinkan"})
			return
		}
		pending := mempool.Pending()
		writeJSON(w, http.StatusOK, map[string]any{
			"count":        len(pending),
			"transactions": pending,
		})
	})

	mux.HandleFunc("/transactions", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			w.Header().Set("Allow", http.MethodPost)
			writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "gunakan POST"})
			return
		}

		r.Body = http.MaxBytesReader(w, r.Body, 1<<20)
		defer r.Body.Close()

		var tx Transaction
		dec := json.NewDecoder(r.Body)
		dec.DisallowUnknownFields()
		if err := dec.Decode(&tx); err != nil {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": "JSON transaksi tidak valid"})
			return
		}

		if err := tx.Verify(LedgerChainID); err != nil {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": "validasi transaksi gagal: " + err.Error()})
			return
		}

		account, err := ledger.AccountInfo(tx.From)
		if err != nil {
			writeJSON(w, http.StatusInternalServerError, map[string]any{"error": "gagal membaca akun"})
			return
		}
		expectedNonce := account.Nonce + 1
		if tx.Nonce != expectedNonce {
			writeJSON(w, http.StatusConflict, map[string]any{
				"error":          "nonce tidak sesuai dengan ledger",
				"expected_nonce": expectedNonce,
				"received_nonce": tx.Nonce,
			})
			return
		}
		// MVP: satu transaksi pending per pengirim.
		for _, pendingTx := range mempool.Pending() {
			if pendingTx.From == tx.From {
				writeJSON(w, http.StatusConflict, map[string]any{
					"error": "masih ada transaksi pengirim ini di mempool; tunggu transaksi diproses",
				})
				return
			}
		}
		if account.Balance < tx.Amount {
			writeJSON(w, http.StatusBadRequest, map[string]any{
				"error":   "saldo tidak mencukupi",
				"balance": account.Balance,
				"amount":  tx.Amount,
			})
			return
		}

		if err := mempool.Add(tx); err != nil {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": err.Error()})
			return
		}

		writeJSON(w, http.StatusAccepted, map[string]any{
			"accepted":      true,
			"finalized":     false,
			"message":       "Transaksi diterima ke mempool, belum masuk blok final",
			"pending_count": mempool.Len(),
		})
	})

	mux.HandleFunc("/balance", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			writeJSON(w, http.StatusMethodNotAllowed, map[string]any{"error": "gunakan GET"})
			return
		}
		address := r.URL.Query().Get("address")
		if address == "" {
			writeJSON(w, http.StatusBadRequest, map[string]any{"error": "parameter address wajib diisi"})
			return
		}
		account, err := ledger.AccountInfo(address)
		if err != nil {
			writeJSON(w, http.StatusBadRequest, map[string]any{"error": "alamat tidak valid atau akun gagal dibaca"})
			return
		}
		writeJSON(w, http.StatusOK, map[string]any{
			"address":  address,
			"balance":  account.Balance,
			"nonce":    account.Nonce,
			"chain_id": LedgerChainID,
		})
	})

	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, http.StatusOK, map[string]any{
			"ok":      true,
			"service": "xeon-v2",
		})
	})

	mux.HandleFunc("/status", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, http.StatusOK, chain.Status())
	})

	mux.HandleFunc("/blocks", func(w http.ResponseWriter, r *http.Request) {
		chain.mu.RLock()
		blocks := append([]Block(nil), chain.Blocks...)
		chain.mu.RUnlock()
		writeJSON(w, http.StatusOK, blocks)
	})

	mux.HandleFunc("/validate", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, http.StatusOK, map[string]bool{
			"valid": chain.Validate(),
		})
	})

	port := os.Getenv("XEON_PORT")
	if port == "" {
		port = "8080"
	}

	if _, err := strconv.Atoi(port); err != nil {
		log.Fatal("XEON_PORT harus berupa angka")
	}

	log.Println("XEON Blockchain development node")
	log.Println("Data:", dataPath)
	log.Println("API hanya menerima koneksi lokal pada port", port)
	log.Println("Konsensus BFT belum diaktifkan")

	log.Fatal(http.ListenAndServe("127.0.0.1:"+port, mux))
}
